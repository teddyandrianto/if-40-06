<div class="container" style="margin-top: 10px;">
    <div class="col-md-12 ">
        <div class="well wel-sm">
           <center>
            <h4>Management Struktur Organisasi</h4>
            <p >Kelas IF-40-06</p>
           </center>
        </div>
        <div  class="col-md-12">
           <center>       
                <img class="img-responsive" src="<?php echo base_url();?>asset/web/img/Struktur-Organisasi.png" width="70%" alt="Chania">
            </center>
        </div> 
    </div>
</div>