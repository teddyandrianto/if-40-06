<footer>
  <div class="container">
  <hr>
    <div class="col-lg-12">
      <p>Copyright © IF-40-06 Telkom university 2016</p>
    </div>
  </div>
</footer>

    <script src="<?php echo base_url();?>/asset/web/js/jquery.js"></script>
    <script src="<?php echo base_url();?>/asset/web/js/bootstrap.min.js"></script>
</body>
</html>
